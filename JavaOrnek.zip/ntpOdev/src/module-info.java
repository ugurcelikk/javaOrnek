module ntpOdev {
}