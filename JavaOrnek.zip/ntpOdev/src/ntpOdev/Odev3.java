package ntpOdev;

import java.util.Scanner;

public class Odev3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int sayi;
		int toplam = 0;
		int[] dizi = new int[10]; // dizinin kaç elemanlı olacağı tanımlanır.

		for (int i = 0; i < 10; i++) { // kullanıcıdan dizinin elemanları alınır.
			System.out.print("Dizinin " + (i + 1) + ". elemanını giriniz: ");
			dizi[i] = scan.nextInt();
		}

		for (int i = 0; i < 9; i++) {
			boolean asal = asal_m(dizi[i]); // sayının asal olup olmadığını kontrol etmek için ilgili metod çağırılır.
			if (asal == false) {
				toplam += dizi[i];
			}

		}
		System.out.printf("Asal olmayıp çift sayı olan değerlerin toplamı: %d",toplam);
		
	}

	public static boolean asal_m(int sayi) {
		int sayac = 0;
		for (int i = 2; i < sayi; i++) { // kullanıcının girdiği sayılardan asal olmayıp çift olanları alan döngü.
			if (sayi % i == 0) {
				sayac++;
			}
		}
		if (sayac == 0) {
			return true;
		} else {
			return false;
		}
	}
}
