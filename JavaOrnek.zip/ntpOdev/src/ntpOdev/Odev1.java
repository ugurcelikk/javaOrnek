package ntpOdev;

import java.util.Scanner;

public class Odev1 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
        int enBuyukEleman = 0;
        int enKucukEleman = 0;
        
        int [] dizi = new int[10];
        
        for(int i = 0; i < 10; i++)
        {
            System.out.print("Dizinin " + (i+1) + ". elemanını giriniz: ");
            dizi[i] = scan.nextInt();
            if(i == 0) {
            	enBuyukEleman = dizi[i];
            	enKucukEleman = dizi[i];
            }
            if(dizi[i] > enBuyukEleman) {
            	enBuyukEleman = dizi[i];
            }
            if(dizi[i] < enKucukEleman) {
            	enKucukEleman = dizi[i];
            }
        }
        System.out.println("Dizinin en büyük elemanı = " + enBuyukEleman);
        System.out.println("Dizinin en kucuk elemanı = " + enKucukEleman);
        
	}

}
