package ntpOdev;

import java.util.Scanner;

public class Odev2 {

	public static void main(String[] args) {
		 
		Scanner scan = new Scanner(System.in);
	        int gecici;
	        int [] dizi = new int[3];
	        
	        for(int i = 0; i < 3; i++)
	        {
	            System.out.print("Dizinin " + (i+1) + ". elemanını giriniz: ");
	            dizi[i] = scan.nextInt();
	        }
	        System.out.println("Dizinin buyukten kucuge dogru sıralanmıs hali:\n");
	        for(int i = 0; i < 2; i++)
	        {
	            for(int j = i+1; j < 3; j++)
	            {
	                if(dizi[j] > dizi[i]) {
	                    gecici = dizi[i];
	                    dizi[i] = dizi[j];
	                    dizi[j] = gecici;
	                }
	            }
	        }
	        for(int i = 0; i < 3; i++)
	        {
	            System.out.println("Dizinin " + (i+1) + ". elemanını : " + dizi[i]);
	        }

	}

}
